from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path.cwd()
DATA = ROOT / "data"
RESULTS = ROOT / "results"
PLOTS = ROOT / "plots"
RESULTS.mkdir(exist_ok=True)
PLOTS.mkdir(exist_ok=True)

def save_csv(frame, name):
    frame.to_csv(RESULTS / name, index=False, encoding="utf-8-sig")


import subprocess
import io
import re

raw_rows=[];word_rows=[]
for path in sorted((DATA/"documents").glob("*.png")):
    completed=subprocess.run(["tesseract",str(path),"stdout","-l","eng","--psm","6","tsv"],check=True,capture_output=True,text=True)
    words=pd.read_csv(io.StringIO(completed.stdout),sep="\t")
    words=words.loc[words.level.eq(5) & words.text.notna()].copy()
    words["text"]=words.text.astype(str)
    words["filename"]=path.name
    lines=words.sort_values(["block_num","par_num","line_num","word_num"]).groupby(["block_num","par_num","line_num"],sort=True).text.agg(" ".join)
    raw_text="\n".join(lines)
    raw_rows.append({"filename":path.name,"raw_text":raw_text})
    word_rows.extend(words[["filename","text","conf","left","top","width","height"]].to_dict("records"))
raw=pd.DataFrame(raw_rows);word_table=pd.DataFrame(word_rows)
save_csv(raw,"ocr_raw.csv");save_csv(word_table,"ocr_words.csv")
print("문서:",len(raw),"OCR 단어:",len(word_table))
print(raw.iloc[0].raw_text)

patterns={
    "document_id":r"(?im)^\s*DOC:\s*(DOC-\d{3})\s*$",
    "date":r"(?im)^\s*DATE:\s*(\d{4}-\d{2}-\d{2})\s*$",
    "sku":r"(?im)^\s*SKU:\s*(KIT-\d{3})\s*$",
    "quantity":r"(?im)^\s*QTY:\s*(\d+)\s*$",
    "unit_price":r"(?im)^\s*PRICE:\s*(\d+\.\d{2})\s*$",
    "adjustment":r"(?im)^\s*ADJUSTMENT:\s*(-?\d+\.\d{2})\s*$",
}
rows=[]
for row in raw.itertuples(index=False):
    normalized=row.raw_text.replace("−","-")
    parsed={"filename":row.filename}
    for field,pattern in patterns.items():
        match=re.search(pattern,normalized)
        parsed[field]=match.group(1) if match else pd.NA
    rows.append(parsed)
fields=pd.DataFrame(rows)
for field in ["quantity","unit_price","adjustment"]:
    fields[field]=pd.to_numeric(fields[field],errors="coerce")
valid_date=pd.to_datetime(fields.date,format="%Y-%m-%d",errors="coerce").notna()
complete=fields[list(patterns)].notna().all(axis=1)
valid=complete & valid_date & fields.quantity.ge(0) & fields.unit_price.ge(0)
fields["status"]=np.where(valid,"parsed","review")
fields["total_value"]=(fields.quantity*fields.unit_price+fields.adjustment).where(valid)
save_csv(fields,"document_fields.csv")
print(fields.to_string(index=False))

truth=pd.read_csv(DATA/"document_truth.csv")
comparison=truth.merge(fields,on="filename",suffixes=("_true","_pred"),validate="one_to_one")
matches={}
for field in ["document_id","date","sku"]:
    matches[field]=comparison[field+"_true"].eq(comparison[field+"_pred"]).fillna(False)
for field in ["quantity","unit_price","adjustment"]:
    matches[field]=np.isclose(comparison[field+"_true"],comparison[field+"_pred"].astype(float),equal_nan=False)
match_frame=pd.DataFrame(matches)
scores=pd.DataFrame({"field":match_frame.columns,"accuracy":match_frame.mean().to_numpy(),"correct":match_frame.sum().to_numpy(),"documents":len(comparison)})
comparison["all_fields_match"]=match_frame.all(axis=1)
save_csv(scores,"field_accuracy.csv");save_csv(comparison,"document_comparison.csv")
print(scores.to_string(index=False))
print("문서 전체 일치:",int(comparison.all_fields_match.sum()),"/",len(comparison))
fig,ax=plt.subplots(figsize=(8,4))
ax.bar(scores.field,scores.accuracy,color="#3a9a90");ax.set(ylim=(0,1.05),ylabel="Exact field match",title="OCR to structured data")
ax.tick_params(axis="x",rotation=20)
fig.tight_layout();fig.savefig(PLOTS/"ocr_field_accuracy.png",dpi=150,bbox_inches="tight");plt.close(fig)
