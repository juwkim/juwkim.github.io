# 숫자만 남기면 부호와 소수점이 사라집니다
# 자료: 금액 파싱을 확인하는 작은 예제
import re
from decimal import Decimal

quantity = 4
price_text = "10.50"
adjustment_text = "-3.50"
wrong_price = int(re.sub(r"\D", "", price_text))
wrong_adjustment = int(re.sub(r"\D", "", adjustment_text))
pattern = r"[+-]?\d+(?:\.\d+)?"
assert re.fullmatch(pattern, price_text)
assert re.fullmatch(pattern, adjustment_text)
correct_total = quantity * Decimal(price_text) + Decimal(adjustment_text)
wrong_total = quantity * wrong_price + wrong_adjustment
print("부호·소수점 보존 합계:", correct_total)
print("숫자만 남긴 합계:", wrong_total)
assert correct_total == Decimal("38.50")


# 형식 검사와 정답 일치는 다른 검사입니다
# 자료: 실습 정답에서 한 필드를 바꾼 오류 예제
import re
import pandas as pd

truth = pd.read_csv("data/document_truth.csv").iloc[0]
changed_quantity = int(truth.quantity) + 1
valid_quantity_format = changed_quantity >= 0
matches_truth = changed_quantity == int(truth.quantity)
date_text = "2026-02-30"
looks_like_date = bool(re.fullmatch(r"\d{4}-\d{2}-\d{2}", date_text))
valid_calendar_date = pd.notna(pd.to_datetime(date_text, format="%Y-%m-%d", errors="coerce"))
print("수량 형식 정상 / 정답 일치:", valid_quantity_format, matches_truth)
print("날짜 형식 정상 / 실제 날짜:", looks_like_date, valid_calendar_date)
assert valid_quantity_format and not matches_truth
assert looks_like_date and not valid_calendar_date
