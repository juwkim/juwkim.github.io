from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path.cwd()
DATA = ROOT / "data"
RESULTS = ROOT / "results"
PLOTS = ROOT / "plots"
RESULTS.mkdir(exist_ok=True)
PLOTS.mkdir(exist_ok=True)

def save_csv(frame, name):
    frame.to_csv(RESULTS / name, index=False, encoding="utf-8-sig")


from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.dummy import DummyClassifier, DummyRegressor
from sklearn.model_selection import GroupKFold, GridSearchCV
from sklearn.metrics import (f1_score, balanced_accuracy_score, classification_report,
    confusion_matrix, ConfusionMatrixDisplay, root_mean_squared_error, mean_absolute_error, r2_score)

records = pd.read_csv(DATA/"asset_records.csv")
splits = pd.read_csv(DATA/"splits.csv")
records = records.merge(splits,on="record_id",validate="one_to_one")
train = records.loc[records.split.eq("train")].copy()
test = records.loc[records.split.eq("test")].copy()
assert set(train.asset_id).isdisjoint(test.asset_id)
numeric = ["vibration","temperature","hours_since_service","asset_age_years"]
categorical = ["manufacturer","device_type"]
features = numeric+categorical
print("Train/Test 행:", len(train), len(test))
print("Train/Test 장비:", train.asset_id.nunique(), test.asset_id.nunique())
print("Train 고장 비율:", round(train.failure_next_week.mean(),3))

def preprocessing():
    return ColumnTransformer([
        ("numeric",Pipeline([("impute",SimpleImputer(strategy="median",add_indicator=True)),("scale",StandardScaler())]),numeric),
        ("category",Pipeline([("impute",SimpleImputer(strategy="most_frequent")),("onehot",OneHotEncoder(handle_unknown="ignore",sparse_output=False))]),categorical),
    ])
folds = list(GroupKFold(n_splits=4).split(train[features],groups=train.asset_id))
classifier = GridSearchCV(Pipeline([("prepare",preprocessing()),("model",LogisticRegression(max_iter=2000,class_weight="balanced"))]),
                          {"model__C":[0.1,1.0,10.0]},cv=folds,scoring="f1_macro",n_jobs=1)
regressor = GridSearchCV(Pipeline([("prepare",preprocessing()),("model",RandomForestRegressor(n_estimators=80,random_state=42,n_jobs=1))]),
                         {"model__max_depth":[4,8,None]},cv=folds,scoring="neg_root_mean_squared_error",n_jobs=1)
classifier.fit(train[features],train.failure_next_week)
regressor.fit(train[features],train.maintenance_minutes)
print("분류 선택:", classifier.best_params_, "CV macro F1:", round(classifier.best_score_,3))
print("회귀 선택:", regressor.best_params_, "CV RMSE:", round(-regressor.best_score_,3))

class_pred = classifier.predict(test[features])
reg_pred = regressor.predict(test[features])
baseline_c = DummyClassifier(strategy="most_frequent").fit(train[features],train.failure_next_week)
baseline_r = DummyRegressor(strategy="mean").fit(train[features],train.maintenance_minutes)
rows=[]
for name,cp,rp in [("selected_model",class_pred,reg_pred),("dummy",baseline_c.predict(test[features]),baseline_r.predict(test[features]))]:
    rows.append({"model":name,"macro_f1":f1_score(test.failure_next_week,cp,average="macro"),
                 "balanced_accuracy":balanced_accuracy_score(test.failure_next_week,cp),
                 "RMSE_minutes":root_mean_squared_error(test.maintenance_minutes,rp),
                 "MAE_minutes":mean_absolute_error(test.maintenance_minutes,rp),"R2":r2_score(test.maintenance_minutes,rp)})
metrics=pd.DataFrame(rows); save_csv(metrics,"asset_metrics.csv")
print(metrics.round(3).to_string(index=False))
print(classification_report(test.failure_next_week,class_pred,zero_division=0))

prediction=test[["record_id","asset_id","failure_next_week","maintenance_minutes"]].copy()
prediction["predicted_failure"]=class_pred
prediction["predicted_minutes"]=reg_pred
prediction["absolute_error_minutes"]=(prediction.maintenance_minutes-reg_pred).abs()
assert prediction.record_id.is_unique and len(prediction)==len(test)
save_csv(prediction,"asset_test_predictions.csv")
fig, axes=plt.subplots(1,2,figsize=(10,4))
ConfusionMatrixDisplay.from_predictions(test.failure_next_week,class_pred,labels=[0,1],display_labels=["no failure","failure"],ax=axes[0],colorbar=False)
axes[0].set_title("Held-out assets")
axes[1].scatter(test.maintenance_minutes,reg_pred,alpha=.65,color="#3a9a90")
limits=[min(test.maintenance_minutes.min(),reg_pred.min()),max(test.maintenance_minutes.max(),reg_pred.max())]
axes[1].plot(limits,limits,"--",color="#66727f")
axes[1].set(xlabel="Actual minutes",ylabel="Predicted minutes",title="Maintenance duration")
fig.tight_layout();fig.savefig(PLOTS/"asset_evaluation.png",dpi=150,bbox_inches="tight");plt.close(fig)
print("예측 행 수:",len(prediction))
