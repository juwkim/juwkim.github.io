# 행을 나눈 평가와 장비를 나눈 평가의 차이
# 자료: 실습 입력 데이터
import pandas as pd
from sklearn.model_selection import train_test_split

records = pd.read_csv("data/asset_records.csv")
left, right = train_test_split(records, test_size=0.2, random_state=42)
row_overlap = set(left.asset_id) & set(right.asset_id)
assigned = records.merge(pd.read_csv("data/splits.csv"), on="record_id", validate="one_to_one")
group_overlap = set(assigned.loc[assigned.split.eq("train"), "asset_id"]) & set(assigned.loc[assigned.split.eq("test"), "asset_id"])
print("행 단위 분할에서 겹치는 장비:", len(row_overlap))
print("제공한 분할에서 겹치는 장비:", len(group_overlap))
assert not group_overlap


# 점검 후 생긴 값이 정답을 알려 주는 경우
# 자료: 실습 입력 데이터의 의도적 오류 비교
import pandas as pd

records = pd.read_csv("data/asset_records.csv")
after_inspection = records.post_inspection_code.eq("confirmed_failure").astype(int)
print("점검 후 코드와 Target의 일치율:", round(after_inspection.eq(records.failure_next_week).mean(), 3))
available_features = ["vibration", "temperature", "hours_since_service", "asset_age_years", "manufacturer", "device_type"]
excluded = ["record_id", "asset_id", "failure_next_week", "maintenance_minutes", "post_inspection_code"]
print("예측 시점에 사용할 Feature:", available_features)
print("입력에서 제외할 열:", excluded)
assert "post_inspection_code" not in available_features
