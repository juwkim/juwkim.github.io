import pandas as pd

records = pd.DataFrame({"repairs": [3, 4], "hours": [100, 1000]})
records["per_1000_hours"] = records["repairs"] / records["hours"] * 1000
pooled_rate = records["repairs"].sum() / records["hours"].sum() * 1000
print(records.to_string(index=False))
print("두 비율의 단순 평균:", round(records["per_1000_hours"].mean(), 3))
print("전체 운용 시간 기준:", round(pooled_rate, 3))
