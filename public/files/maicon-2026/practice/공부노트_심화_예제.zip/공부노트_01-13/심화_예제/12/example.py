import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import IsolationForest

rng = np.random.default_rng(42)
reference = rng.normal(size=(100, 3))
new = np.vstack([rng.normal(size=(20, 3)),
                 rng.normal(loc=2.8, size=(20, 3))])
detector = make_pipeline(StandardScaler(), IsolationForest(
    contamination=0.05, random_state=42,
))
detector.fit(reference)
print("참조 데이터 후보 비율:", (detector.predict(reference) == -1).mean())
print("새 데이터 후보 비율:", (detector.predict(new) == -1).mean())
