from sklearn.datasets import make_regression
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold, cross_val_predict
from sklearn.metrics import mean_absolute_error

X_train, y_train = make_regression(n_samples=180, n_features=3,
                                  noise=8, random_state=42)
model = RandomForestRegressor(n_estimators=80, random_state=42)
folds = KFold(n_splits=5, shuffle=True, random_state=42)
oof = cross_val_predict(model, X_train, y_train, cv=folds)
model.fit(X_train, y_train)
print("Train 재예측 MAE:", round(mean_absolute_error(y_train, model.predict(X_train)), 3))
print("Out-of-fold MAE:", round(mean_absolute_error(y_train, oof), 3))
print("OOF 예측 수:", len(oof))
