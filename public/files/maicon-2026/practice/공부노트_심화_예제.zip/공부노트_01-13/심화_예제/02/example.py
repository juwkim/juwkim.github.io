import pandas as pd
from sklearn.preprocessing import OneHotEncoder

train = pd.DataFrame({"region": ["A", "A", "A", "A", "B", "C"]})
new = pd.DataFrame({"region": ["A", "D"]})
encoder = OneHotEncoder(
    min_frequency=2, handle_unknown="infrequent_if_exist",
    sparse_output=False,
)
encoder.fit(train)
result = pd.DataFrame(encoder.transform(new),
                      columns=encoder.get_feature_names_out())
print(result.to_string(index=False))
