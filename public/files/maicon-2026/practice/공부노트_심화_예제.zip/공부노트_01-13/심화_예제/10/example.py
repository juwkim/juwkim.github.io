import numpy as np

time_seconds = np.array([0.0, 1.0, 9.0])
counts = np.array([0.0, 10.0, 2.0])
duration = np.diff(np.append(time_seconds, 10.0))
print("샘플 평균:", counts.mean())
print("각 값의 유지 시간:", duration.tolist())
print("유지 가정의 시간 가중 평균:", np.average(counts, weights=duration))
