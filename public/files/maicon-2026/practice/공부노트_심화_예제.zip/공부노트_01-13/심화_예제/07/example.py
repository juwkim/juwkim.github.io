import numpy as np
import pandas as pd
from sklearn.metrics import precision_score, recall_score, f1_score

actual = np.array([0, 0, 1, 0, 1, 1, 0, 1])
probability = np.array([0.1, 0.2, 0.35, 0.4, 0.55, 0.65, 0.7, 0.9])
rows = []
for threshold in [0.3, 0.5, 0.7]:
    predicted = (probability >= threshold).astype(int)
    rows.append({"threshold": threshold,
                 "precision": precision_score(actual, predicted),
                 "recall": recall_score(actual, predicted),
                 "f1": f1_score(actual, predicted)})
print(pd.DataFrame(rows).round(3).to_string(index=False))
