import numpy as np

width, height = 200, 100
xmin, ymin, xmax, ymax = 40.0, 20.0, 120.0, 80.0
assert 0 <= xmin < xmax <= width and 0 <= ymin < ymax <= height
cx = (xmin + xmax) / 2 / width
cy = (ymin + ymax) / 2 / height
bw = (xmax - xmin) / width
bh = (ymax - ymin) / height
restored = np.array([(cx - bw / 2) * width, (cy - bh / 2) * height,
                     (cx + bw / 2) * width, (cy + bh / 2) * height])
print("정규화한 중심 xywh:", [cx, cy, bw, bh])
print("복원한 원본 xyxy:", restored.tolist())
