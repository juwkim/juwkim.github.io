import numpy as np
from sklearn.datasets import make_blobs
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score

X, _ = make_blobs(n_samples=180, centers=[[0, 0], [1.5, 0], [0, 1.5]],
                  cluster_std=1.1, random_state=42)
reference = KMeans(n_clusters=3, n_init=10, random_state=42).fit_predict(X)
rng = np.random.default_rng(42)
agreement = []
for seed in range(5):
    sampled = X[rng.integers(0, len(X), size=len(X))]
    candidate = KMeans(n_clusters=3, n_init=10, random_state=seed).fit(sampled)
    agreement.append(adjusted_rand_score(reference, candidate.predict(X)))
print("재표집별 ARI:", np.round(agreement, 3).tolist())
print("평균 ARI:", round(float(np.mean(agreement)), 3))
