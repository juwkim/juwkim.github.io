import io
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

csv_text = "record_id,amount\n0012,12\n0013,error\n0014,\n"
df = pd.read_csv(io.StringIO(csv_text), dtype={"record_id": "string"})
df["amount_raw"] = df["amount"]
df["amount_numeric"] = pd.to_numeric(df["amount"], errors="coerce")
df["parse_failed"] = df["amount_raw"].notna() & df["amount_numeric"].isna()
print(df.to_string(index=False))

counts = pd.Series([4.0, np.nan, 0.0], name="count")
print("관측한 값만의 평균:", counts.mean())
print("모르는 값을 0으로 바꾼 평균:", counts.fillna(0).mean())
empty = pd.Series([np.nan, np.nan])
print("전부 결측인 합계:", empty.sum())
print("최소 관측 1개를 요구한 합계:", empty.sum(min_count=1))

left = pd.DataFrame({"id": ["A", "A", None], "quantity": [5, 7, 9]})
right = pd.DataFrame({"id": ["A", "A", None], "version": [1, 2, 1],
                      "owner": ["old", "new", "unknown"]})
print("검사 없는 Join 행:", len(left.merge(right, on="id", how="left")))
try:
    left.merge(right, on="id", how="left", validate="many_to_one")
except pd.errors.MergeError:
    print("validate가 오른쪽 중복 키를 발견했습니다.")

# 이 예제의 기준표는 가장 큰 version을 채택한다는 규칙이 있습니다.
master = right.dropna(subset=["id"]).sort_values("version").drop_duplicates("id", keep="last")
joined = left.merge(master, on="id", how="left", validate="many_to_one", indicator=True)
print(joined.to_string(index=False))

result = pd.DataFrame({"record_id": ["R42", "R09"]}, index=[42, 9])
prediction = pd.Series([0.2, 0.8])
result["wrong_alignment"] = prediction
result["same_row_order"] = prediction.to_numpy()
print(result.to_string())

series = pd.Series([10.0, 20.0, 90.0, 40.0])
past_mean = series.shift(1).rolling(2, min_periods=2).mean()
contains_current = series.rolling(2, min_periods=2).mean()
print(pd.DataFrame({"value": series, "current_included": contains_current,
                    "past_only": past_mean}).to_string(index=False))

from sklearn.preprocessing import StandardScaler, MinMaxScaler

train_values = np.array([[10.0], [20.0]])
new_values = np.array([[30.0]])
minmax = MinMaxScaler().fit(train_values)
standard = StandardScaler().fit(np.array([[7.0], [7.0]]))
print("새 값의 MinMax 결과:", minmax.transform(new_values).ravel().tolist())
print("상수 Feature의 StandardScaler 결과:", standard.transform([[7.0]]).ravel().tolist())
print("상수 Feature의 scale_:", standard.scale_.tolist())

train_categories = pd.Series(["A", "B"], name="region")
new_categories = pd.Series(["B", "C"], name="region")
train_onehot = pd.get_dummies(train_categories, prefix="region", dtype=int)
new_onehot = pd.get_dummies(new_categories, prefix="region", dtype=int)
aligned = new_onehot.reindex(columns=train_onehot.columns, fill_value=0)
print("Train 열:", train_onehot.columns.tolist())
print("새 데이터 열:", new_onehot.columns.tolist())
print("Train 열에 맞춘 결과:")
print(aligned.to_string(index=False))

x = np.arange(-5, 6, dtype=float)
y = x ** 2
print("Pearson correlation:", round(pd.Series(x).corr(pd.Series(y)), 6))
fig, ax = plt.subplots(figsize=(6, 4))
ax.scatter(x, y, color="#3a9a90", s=50)
ax.set(xlabel="x", ylabel="x squared", title="Zero Pearson correlation, clear nonlinear pattern")
ax.grid(alpha=.2)
fig.tight_layout(); fig.savefig("nonlinear_correlation.png", dpi=150); plt.close(fig)

from sklearn.metrics import (accuracy_score, balanced_accuracy_score,
    precision_score, recall_score, roc_auc_score, average_precision_score)

actual = np.array([0] * 95 + [1] * 5)
scores = np.r_[np.linspace(.01, .4, 95), [.15, .35, .55, .75, .95]]
predicted = (scores >= .5).astype(int)
baseline = np.zeros_like(actual)
for name, pred in [("model", predicted), ("always_zero", baseline)]:
    print(name, "Accuracy:", round(accuracy_score(actual, pred), 3),
          "Balanced Accuracy:", round(balanced_accuracy_score(actual, pred), 3),
          "Recall:", round(recall_score(actual, pred, zero_division=0), 3))
print("ROC-AUC:", round(roc_auc_score(actual, scores), 3))
print("Average Precision:", round(average_precision_score(actual, scores), 3))

from sklearn.metrics import mean_absolute_error, root_mean_squared_error

actual_amount = np.array([10.0, 20.0, 100.0])
predicted_log = np.log1p([12.0, 22.0, 80.0])
predicted_amount = np.expm1(predicted_log)
print("원래 단위의 예측:", predicted_amount.round(3).tolist())
print("MAE:", round(mean_absolute_error(actual_amount, predicted_amount), 3))
print("RMSE:", round(root_mean_squared_error(actual_amount, predicted_amount), 3))

import re

texts = ["12.5", "-3", "2026-08-01"]
for text in texts:
    digits_only = re.sub(r"[^0-9]", "", text)
    print("원문:", text, "숫자만 남긴 결과:", digits_only)
number = "-3.25"
valid_number = re.fullmatch(r"[+-]?\d+(?:\.\d+)?", number)
print("부호·소수점을 보존한 값:", float(number) if valid_number else None)

records = pd.DataFrame({"id": ["A", "B"], "score": [1.0, np.nan]})
records["score"] = records["score"].fillna(0)
records.loc[records["id"].eq("A"), "score"] = 2
records.to_csv("checked_result.csv", index=False, encoding="utf-8-sig")
saved = pd.read_csv("checked_result.csv", dtype={"id": "string"})
assert len(saved) == len(records)
assert saved["id"].is_unique
assert saved.columns.tolist() == ["id", "score"]
print(saved.to_string(index=False))
