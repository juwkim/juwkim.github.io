import pandas as pd

sensor = pd.Series([10.0, 20.0, 30.0, 40.0], name="value")
result = pd.DataFrame({
    "value": sensor,
    "includes_current": sensor.rolling(3, min_periods=2).mean(),
    "past_only": sensor.shift(1).rolling(3, min_periods=2).mean(),
})
print(result.to_string(index=False))
