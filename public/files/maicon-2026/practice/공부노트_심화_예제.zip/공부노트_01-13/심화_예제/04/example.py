import numpy as np
from scipy.stats import bootstrap

values = np.array([2.0, 3.0, 3.0, 4.0, 8.0])
estimate = bootstrap(
    (values,), np.mean, n_resamples=2000, method="percentile",
    confidence_level=0.95, rng=np.random.default_rng(42),
)
print("표본 평균:", values.mean())
print("95% Bootstrap 구간:",
      round(estimate.confidence_interval.low, 2),
      round(estimate.confidence_interval.high, 2))
