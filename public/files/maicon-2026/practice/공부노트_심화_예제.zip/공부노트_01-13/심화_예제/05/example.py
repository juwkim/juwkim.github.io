from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

rng = np.random.default_rng(42)
x = rng.normal(size=5000)
y = 0.7 * x + rng.normal(scale=0.7, size=5000)
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
axes[0].scatter(x, y, s=9, alpha=0.12, color="#287f78")
axes[0].set_title("Scatter: overlapping points")
counts = axes[1].hexbin(x, y, gridsize=30, mincnt=1,
                        bins="log", cmap="viridis")
fig.colorbar(counts, ax=axes[1], label="Count (log color scale)")
axes[1].set_title("Hexbin: observations per cell")
for ax in axes:
    ax.set(xlabel="x", ylabel="y")
fig.tight_layout()
fig.savefig("hexbin_comparison.png", dpi=150, bbox_inches="tight")
plt.close(fig)
print("집계한 점 수:", int(counts.get_array().sum()))
