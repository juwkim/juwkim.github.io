import pandas as pd

example = pd.DataFrame({"score": [70.0, None, 90.0]})
example["score_missing"] = example["score"].isna().astype("int8")
example["score_filled"] = example["score"].fillna(example["score"].median())
print(example.to_string(index=False))
