# 실패 사진을 0으로 채우면 장면의 의미가 달라집니다
# 자료: 실습에서 저장한 탐지 결과
import pandas as pd

counts = pd.read_csv("results/photo_counts.csv")
proper = counts.groupby("scene").person_count.agg(mean="mean", processed="count")
filled = counts.assign(person_count=counts.person_count.fillna(0)).groupby("scene").person_count.mean()
comparison = proper.join(filled.rename("mean_after_zero_fill"))
comparison["registered"] = counts.groupby("scene").size()
print(counts[["photo_id", "scene", "status", "person_count"]].to_string(index=False))
print(comparison.to_string())
assert pd.isna(comparison.loc["C", "mean"])
assert comparison.loc["C", "mean_after_zero_fill"] == 0


# Confidence를 높여도 정확도를 바로 알 수는 없습니다
# 자료: 실습에서 저장한 객체별 결과
import pandas as pd

detections = pd.read_csv("results/photo_detections.csv")
rows = []
for threshold in [0.25, 0.50, 0.75]:
    kept = detections.loc[detections.confidence.ge(threshold)]
    rows.append({"threshold": threshold, "person": int(kept.class_name.eq("person").sum()), "vehicle": int(kept.class_name.isin(["car", "bus", "truck"]).sum())})
print(pd.DataFrame(rows).to_string(index=False))
print("이 표의 기준: 기존 NMS 결과의 재필터링, 정답 기반 정확도 평가 아님")
