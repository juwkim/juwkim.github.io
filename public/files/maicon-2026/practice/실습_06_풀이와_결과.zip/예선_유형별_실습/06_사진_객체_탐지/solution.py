from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path.cwd()
DATA = ROOT / "data"
RESULTS = ROOT / "results"
PLOTS = ROOT / "plots"
RESULTS.mkdir(exist_ok=True)
PLOTS.mkdir(exist_ok=True)

def save_csv(frame, name):
    frame.to_csv(RESULTS / name, index=False, encoding="utf-8-sig")


import cv2
import torch
from ultralytics import YOLO

torch.set_num_threads(2)
registry=pd.read_csv(DATA/"photo_registry.csv")
registry["updated_at"]=pd.to_datetime(registry.updated_at,utc=True)
registry=registry.sort_values("updated_at").drop_duplicates("photo_id",keep="last")
assert registry.photo_id.is_unique
model=YOLO(str(ROOT.parent/"_models/yolov5su.pt"))
selected_names={"person","car","bus","truck"}
selected_ids=[key for key,value in model.names.items() if value in selected_names]
vehicle_names={"car","bus","truck"}
print("처리할 사진:",len(registry),"집계 클래스:",sorted(selected_names))

summaries=[]; details=[]; rendered=[]
for row in registry.itertuples(index=False):
    path=DATA/"images"/row.filename
    summary={"photo_id":row.photo_id,"filename":row.filename,"scene":row.scene,
             "person_count":pd.NA,"vehicle_count":pd.NA,"status":"missing_file"}
    if path.is_file():
        image=cv2.imread(str(path))
        if image is None:
            summary["status"]="read_failed"
        else:
            # This API accepts an OpenCV BGR NumPy image.
            result=model.predict(image,imgsz=640,conf=.25,iou=.45,classes=selected_ids,device="cpu",verbose=False)[0]
            names=[result.names[int(c)] for c in result.boxes.cls.cpu().tolist()]
            summary.update(status="ok",person_count=names.count("person"),vehicle_count=sum(name in vehicle_names for name in names))
            for i,(box,confidence,class_id) in enumerate(zip(result.boxes.xyxy.cpu().numpy(),result.boxes.conf.cpu().numpy(),result.boxes.cls.cpu().numpy())):
                details.append({"photo_id":row.photo_id,"filename":row.filename,"detection_index":i,"class_name":result.names[int(class_id)],"confidence":float(confidence),"xmin":float(box[0]),"ymin":float(box[1]),"xmax":float(box[2]),"ymax":float(box[3])})
            if row.filename.startswith("CAM"): rendered.append((row.filename,result.plot()))
    summaries.append(summary)
counts=pd.DataFrame(summaries)
counts[["person_count","vehicle_count"]]=counts[["person_count","vehicle_count"]].astype("Int64")
detections=pd.DataFrame(details,columns=["photo_id","filename","detection_index","class_name","confidence","xmin","ymin","xmax","ymax"])
assert len(counts)==len(registry)
save_csv(counts,"photo_counts.csv");save_csv(detections,"photo_detections.csv")
print(counts.to_string(index=False))

scene=counts.groupby("scene",as_index=False).agg(
    registered_images=("photo_id","size"),processed_images=("person_count","count"),
    person_detections=("person_count",lambda s:s.sum(min_count=1)),
    vehicle_detections=("vehicle_count",lambda s:s.sum(min_count=1)),
    mean_person_per_processed_image=("person_count","mean"),
)
scene["failed_images"]=scene.registered_images-scene.processed_images
save_csv(scene,"scene_summary.csv")
comparisons=[]
for threshold in [.25,.50,.75]:
    subset=detections.loc[detections.confidence.ge(threshold)]
    comparisons.append({"confidence_threshold":threshold,"person_detections":int(subset.class_name.eq("person").sum()),"vehicle_detections":int(subset.class_name.isin(vehicle_names).sum())})
comparison=pd.DataFrame(comparisons);save_csv(comparison,"confidence_comparison.csv")
print(scene.to_string(index=False));print(comparison.to_string(index=False))
fig,axes=plt.subplots(1,len(rendered),figsize=(12,5))
for ax,(filename,bgr) in zip(np.atleast_1d(axes),rendered):
    ax.imshow(cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB));ax.set_title(filename);ax.axis("off")
fig.tight_layout();fig.savefig(PLOTS/"detection_review.png",dpi=130,bbox_inches="tight");plt.close(fig)
