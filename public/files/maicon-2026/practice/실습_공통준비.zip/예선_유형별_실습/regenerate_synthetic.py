"""원본을 덮어쓰지 않고 새 폴더에 합성 입력을 재생성합니다."""
from pathlib import Path
import json, sys
import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont
if len(sys.argv)!=2:
    raise SystemExit("Usage: python regenerate_synthetic.py NEW_OUTPUT_FOLDER")
PACK=Path(sys.argv[1]).resolve()
if PACK.exists():
    raise SystemExit("이미 있는 폴더입니다. 새로운 출력 폴더를 지정합니다.")
PACK.mkdir(parents=True)
FOLDERS={1: '01_정형_전처리와_집계', 2: '02_정형_분류와_회귀', 3: '03_센서_시계열', 4: '04_텍스트_분류', 5: '05_사진_분류', 6: '06_사진_객체_탐지', 7: '07_영상_분석', 8: '08_OCR_문서_구조화'}
def directory(n):
    d=PACK/FOLDERS[n];(d/"data").mkdir(parents=True,exist_ok=True);return d
def csv(df,path):df.to_csv(path,index=False,encoding="utf-8-sig")

def generate():
    rng=np.random.default_rng(2026)
    # 01. Mixed formats, duplicate events, registry versions and nested JSON.
    d=directory(1)/'data'
    rows=[]
    for i in range(180):
        item=['water','battery','medical'][i%3]
        rows.append({'event_id':f'E{i:04d}','unit_id':f'U{i%5+1:03d}',
          'timestamp':(pd.Timestamp('2026-08-01',tz='UTC')+pd.Timedelta(hours=i)).isoformat(),
          'item_id':item,'quantity':str(int(rng.integers(1,10))),
          'quantity_unit':'box' if i%4==0 else 'piece',
          'updated_at':(pd.Timestamp('2026-08-10',tz='UTC')+pd.Timedelta(minutes=i)).isoformat()})
    for i in [3,17,45,72]: rows[i]['quantity']='error'
    for i in [5,61]: rows[i]['quantity']=''
    rows[9]['quantity']='-3'; rows[13]['quantity_unit']='pallet'
    rows[14]['unit_id']='U999'; rows[18]['unit_id']=None
    rows[22]['timestamp']='not-a-date'; rows[27]['item_id']='unknown'
    rows[35]['quantity']='2.5'; rows[35]['quantity_unit']='piece'
    for i in [10,20,30,40]:
        row=rows[i].copy(); row['quantity']='12'; row['updated_at']='2026-08-11T00:00:00+00:00'; rows.append(row)
    csv(pd.DataFrame(rows),d/'logistics_raw.csv')
    registry=[{'unit_id':f'U{i:03d}','profile':{'name':f'지원팀{i}','region':['north','south'][i%2]},'updated_at':'2026-08-01T00:00:00Z'} for i in range(1,7)]
    registry.append({'unit_id':'U003','profile':{'name':'지원팀3-개편','region':'east'},'updated_at':'2026-08-09T00:00:00Z'})
    (d/'unit_registry.json').write_text(json.dumps(registry,ensure_ascii=False,indent=2))
    csv(pd.DataFrame({'item_id':['water','battery','medical'],'pieces_per_box':[24,8,10]}),d/'item_catalog.csv')
    # 02. Repeated asset observations; two different targets and an unavailable field.
    d=directory(2)/'data'; rows=[]
    for asset in range(90):
        age=float(rng.uniform(1,14)); latent=float(rng.normal())
        for visit in range(8):
            vibration=max(0.05,float(rng.lognormal(0.5+latent*.15,.45)))
            temperature=float(rng.normal(43+6*vibration,7))
            hours=float(rng.uniform(1,500)); maker=['A','B','C'][asset%3]
            risk=-5.0+1.1*vibration+.04*(temperature-40)+.12*age+.004*hours+latent*.3
            failure=bool(rng.random()<1/(1+np.exp(-risk)))
            duration=max(5,20+8*vibration+.3*hours+.6*age+8*latent+25*failure+float(rng.normal(0,9)))
            rows.append({'record_id':f'R{asset:03d}_{visit:02d}','asset_id':f'A{asset:03d}',
                'vibration':vibration,'temperature':temperature,'hours_since_service':hours,
                'asset_age_years':age,'manufacturer':maker,'device_type':['sensor','generator','pump'][asset%3],
                'failure_next_week':int(failure),'maintenance_minutes':round(duration,3),
                'post_inspection_code':'confirmed_failure' if failure else 'confirmed_ok'})
    df=pd.DataFrame(rows)
    for col in ['vibration','temperature','hours_since_service']:
        df.loc[rng.choice(df.index,size=24,replace=False),col]=np.nan
    from sklearn.model_selection import GroupShuffleSplit
    tr,te=next(GroupShuffleSplit(n_splits=1,test_size=.2,random_state=42).split(df,groups=df.asset_id))
    df.loc[te[:8],'device_type']='new_sensor'
    csv(df,d/'asset_records.csv')
    split=pd.DataFrame({'record_id':df.record_id,'split':'train'}); split.loc[te,'split']='test'
    csv(split,d/'splits.csv')
    # 03. Six sensors, dropped logs, invalid values and complete missing hours.
    d=directory(3)/'data'; rows=[]
    for sensor in range(6):
        for step in range(96*12):
            hour=step//12
            if sensor==2 and 16<=hour<19: continue
            if rng.random()<.035: continue
            ts=pd.Timestamp('2026-08-01',tz='UTC')+pd.Timedelta(minutes=step*5,seconds=int(rng.integers(0,31)))
            temperature=24+sensor*.8+5*np.sin(2*np.pi*(hour%24)/24)+.04*hour+float(rng.normal(0,.7))
            if step==440 and sensor==1: temperature=999
            rows.append({'log_id':f'S{sensor:02d}_{step:04d}','sensor_id':f'S{sensor:02d}',
                'timestamp':ts.isoformat(),'temperature_c':round(temperature,3),
                'energy_kwh':round(float(rng.uniform(.1,.5)+.03*sensor),4)})
    df=pd.DataFrame(rows).sample(frac=1,random_state=42).reset_index(drop=True)
    csv(df,d/'sensor_logs.csv')
    (d/'sensor_config.json').write_text(json.dumps({'timezone':'UTC','expected_records_per_hour':12,'valid_temperature_range_c':[-20,70],'start':'2026-08-01T00:00:00Z','periods':96,'test_starts':'2026-08-04T00:00:00Z'},indent=2))
    # 04. Template groups, negations, distracting context and exact duplicates.
    d=directory(4)/'data'; rows=[]
    phrases={
      'maintenance':['냉각 팬에서 큰 소음이 들립니다','전원 스위치가 눌리지 않습니다','장비 연결부의 진동을 점검해 주세요','발전기 출력이 일정하지 않습니다','센서 표면이 손상되어 교체가 필요합니다','모터 회전이 멈추는 현상이 반복됩니다','배터리 충전 표시가 정상과 다릅니다','계기판의 경고등이 계속 켜집니다','펌프 압력이 낮아 사용이 어렵습니다','케이블 단자 부식 상태를 확인 바랍니다'],
      'logistics':['생수 박스의 배송 수량을 확인해 주세요','예비 부품의 재고가 부족합니다','보급품 도착 예정일을 알려 주세요','창고 물품의 입고 내역이 필요합니다','포장 상자에 적힌 수량과 실제 수량이 다릅니다','소모품 발주 목록을 변경하려고 합니다','운송 일정이 늦어 대체 배송이 필요합니다','물품 출고 신청을 취소해 주세요','보급 요청의 담당 창고를 확인 바랍니다','재고 목록의 품목 코드를 정리해 주세요'],
      'network':['무선 접속이 자주 끊어집니다','계정 로그인 후 서버 응답이 없습니다','망 연결 상태를 확인해 주세요','공유 폴더의 파일을 내려받을 수 없습니다','통신 장비의 인터넷 접속을 복구해 주세요','서버 인증 오류로 작업을 진행할 수 없습니다','네트워크 주소가 할당되지 않습니다','메시지 송수신 시간이 너무 깁니다','접속 권한 설정을 변경해 주세요','업무 시스템의 연결 제한을 풀어 주세요']}
    context=['물품 배송에는 문제가 없습니다','장비 수리는 완료했습니다','망 접속 문제는 발생하지 않았습니다']
    for label,templates in phrases.items():
        for group,phrase in enumerate(templates):
            for variant in range(12):
                text=f'접수 {variant+1}번. {phrase}. {context[variant%3]}. 확인 위치: 구역 {variant%4+1}.'
                rows.append({'report_id':f'{label[0]}{group:02d}_{variant:02d}',
                    'template_group':f'{label}_{group:02d}','text':text,'label':label,
                    'team':f'팀{variant%4+1}'})
    for i in [7,19,41,82,113,144]:
        row=rows[i].copy(); row['report_id']+='_repeat'; rows.append(row)
    for i in range(3): rows.append({'report_id':f'empty_{i}','template_group':'empty','text':None,'label':'network','team':'팀1'})
    df=pd.DataFrame(rows)
    groups=df.loc[df.template_group.ne('empty'),['template_group','label']].drop_duplicates()
    from sklearn.model_selection import train_test_split
    gt,ge=train_test_split(groups,test_size=.3,random_state=42,stratify=groups.label)
    df['split']=np.where(df.template_group.isin(ge.template_group),'test','train')
    with (d/'reports.jsonl').open('w') as f:
        for row in df.to_dict('records'): f.write(json.dumps(row,ensure_ascii=False)+'\n')
    d=directory(7)/"data"; (d/"videos").mkdir(exist_ok=True)
    import cv2
    fps=29.97; size=(480,270); frames=300
    writer=cv2.VideoWriter(str(d/'videos/moving_shapes.mp4'),cv2.VideoWriter_fourcc(*'mp4v'),fps,size)
    assert writer.isOpened()
    truth=[]
    for i in range(frames):
        frame=np.full((size[1],size[0],3),245,dtype=np.uint8)
        objects=[]
        if i>=30: objects.append(('red',60+int(i*.3)%150,70,35,28,(40,40,220)))
        if 90<=i<210: objects.append(('blue',280-int(i*.15),170,42,30,(220,80,40)))
        if 180<=i<270: objects.append(('green',350,60+i%40,30,24,(30,170,50)))
        for name,x,y,w,h,color in objects:
            cv2.rectangle(frame,(x,y),(x+w,y+h),color,-1)
        writer.write(frame)
        truth.append({'frame_number':i,'time_seconds':i/fps,'object_count':len(objects)})
    writer.release(); csv(pd.DataFrame(truth),d/'shape_frame_truth.csv')
    # 08. Precise document images with ground truth fields and visible typography.
    d=directory(8)/'data'; (d/'documents').mkdir(exist_ok=True)
    candidates=[Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
                Path("C:/Windows/Fonts/arial.ttf"),Path("/System/Library/Fonts/Supplemental/Arial.ttf")]
    font_path=next((str(p) for p in candidates if p.is_file()),None)
    if font_path is None: raise SystemExit("문서 생성에 사용할 TrueType 글꼴을 지정해 주세요.")
    font=ImageFont.truetype(font_path,34)
    big=ImageFont.truetype(font_path,42)
    truth=[]
    for i in range(12):
        sku=f'KIT-{i+1:03d}'; quantity=int(rng.integers(2,40)); price=round(float(rng.uniform(4,45)),2)
        date=f'2026-08-{i+1:02d}'; adjustment=-2.5 if i%3==0 else 0.0
        fields={'DOC':f'DOC-{i+1:03d}','DATE':date,'SKU':sku,'QTY':str(quantity),'PRICE':f'{price:.2f}','ADJUSTMENT':f'{adjustment:.2f}'}
        image=Image.new('RGB',(1050,630),'white'); draw=ImageDraw.Draw(image)
        draw.text((55,35),'SUPPLY RECORD',font=big,fill='#243a43')
        for j,(key,value) in enumerate(fields.items()): draw.text((55,120+j*70),f'{key}: {value}',font=font,fill='black')
        if i in [8,9]: image=image.rotate(1.2 if i==8 else -1.5,resample=Image.Resampling.BICUBIC,expand=False,fillcolor='white')
        if i in [10,11]: image=image.resize((525,315)).resize((1050,630))
        filename=f'document_{i+1:03d}.png'; image.save(d/'documents'/filename)
        truth.append({'filename':filename,'document_id':fields['DOC'],'date':date,'sku':sku,
                      'quantity':quantity,'unit_price':price,'adjustment':adjustment})
    csv(pd.DataFrame(truth),d/'document_truth.csv')
    (d/'dataset_source.json').write_text(json.dumps({'kind':'constructed document images','seed':2026,'fields':'IDs, ISO dates, integer quantities, decimal prices, signed adjustments','variations':'clean / slight rotation / lower resolution','not_real_documents':True},indent=2))
    print('합성 데이터 재생성 완료:',PACK)

generate()
