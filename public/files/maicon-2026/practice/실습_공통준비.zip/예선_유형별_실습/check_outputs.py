"""Check saved submissions, IDs, missing-value states and metric consistency.

This checks result files. Review preprocessing/split/model choices in the Notebook.
"""
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
from sklearn.metrics import f1_score, accuracy_score, root_mean_squared_error

FOLDERS={1:'01_정형_전처리와_집계',2:'02_정형_분류와_회귀',3:'03_센서_시계열',4:'04_텍스트_분류',5:'05_사진_분류',6:'06_사진_객체_탐지',7:'07_영상_분석',8:'08_OCR_문서_구조화'}

def require(condition,message):
    if not bool(condition): raise ValueError(message)

def read(folder,filename,columns=(),sub='results'):
    path=folder/sub/filename
    require(path.is_file(),f'파일 누락: {sub}/{filename}')
    frame=pd.read_csv(path)
    require(set(columns)<=set(frame.columns),f'{filename}: 필수 열 누락')
    require(not any(str(c).startswith('Unnamed:') for c in frame),f'{filename}: 불필요한 Index 열')
    return frame

def unique(frame,key):
    columns=[key] if isinstance(key,str) else key
    require(not frame[columns].isna().any().any(),f'{key}: 빈 키')
    require(not frame.duplicated(key).any(),f'{key}: 중복 키')

def same_keys(left,right,key):
    unique(left,key); unique(right,key)
    require(set(map(tuple,left[[key] if isinstance(key,str) else key].to_numpy()))==
            set(map(tuple,right[[key] if isinstance(key,str) else key].to_numpy())),f'{key}: 대상 키 불일치')

def close(a,b,message):
    require(np.allclose(a,b,rtol=1e-7,atol=1e-8,equal_nan=True),message)

def check(n,root):
    d=root/FOLDERS[n]
    require(d.is_dir(),'유형 폴더 누락')
    for p in ['starter.ipynb','solution.ipynb','solution.py']:
        require((d/p).is_file(),f'{p} 누락')
    require(any((d/'plots').glob('*.png')),'그래프 누락')
    if n==1:
        raw=read(d,'logistics_raw.csv',sub='data')
        clean=read(d,'clean_records.csv',['event_id','quantity_piece'])
        rejected=read(d,'rejected_records.csv',['event_id','reject_reason'])
        together=pd.concat([clean,rejected],ignore_index=True)
        unique(together,'event_id')
        require(set(together.event_id)==set(raw.event_id),'전처리 도중 event_id 누락·추가')
        require(clean.quantity_piece.notna().all() and clean.quantity_piece.ge(0).all(),'유효 수량의 결측·음수')
        close(clean.quantity_piece,clean.quantity_piece.round(),'piece 수량의 소수')
        require(rejected.reject_reason.notna().all(),'제외 이유 누락')
        daily=read(d,'daily_unit_summary.csv');totals=read(d,'unit_totals.csv')
        unique(daily,['day','unit_id']);unique(totals,'unit_id')
        close(daily.quantity_piece.sum(),clean.quantity_piece.sum(),'일별 합계 불일치')
        close(totals.quantity_piece.sum(),clean.quantity_piece.sum(),'팀별 합계 불일치')
        close(daily.valid_records.sum(),len(clean),'일별 유효 행 수 불일치')
        require(totals.loc[totals.valid_records.eq(0),'quantity_piece'].isna().all(),'미관측 팀의 수량을 0으로 처리함')
        read(d,'quality_report.csv',['check','value'])
    elif n==2:
        raw=read(d,'asset_records.csv',sub='data');split=read(d,'splits.csv',sub='data')
        expected=raw.merge(split,on='record_id',validate='one_to_one')
        test=expected.loc[expected.split.eq('test')]
        train=expected.loc[expected.split.eq('train')]
        require(set(train.asset_id).isdisjoint(test.asset_id),'Train/Test 장비 ID 겹침')
        pred=read(d,'asset_test_predictions.csv',['record_id','asset_id','predicted_failure','predicted_minutes'])
        same_keys(pred,test,'record_id')
        merged=pred.merge(test,on='record_id',suffixes=('_pred','_source'),validate='one_to_one')
        require(merged.asset_id_pred.eq(merged.asset_id_source).all(),'장비 ID 대응 불일치')
        close(merged.failure_next_week_pred,merged.failure_next_week_source,'실제 분류 Target 대응 불일치')
        close(merged.maintenance_minutes_pred,merged.maintenance_minutes_source,'실제 회귀 Target 대응 불일치')
        require(pred.predicted_failure.isin([0,1]).all(),'알 수 없는 분류 Label')
        require(np.isfinite(pred.predicted_minutes).all(),'비유한 회귀 예측')
        metrics=read(d,'asset_metrics.csv').set_index('model')
        close(metrics.loc['selected_model','macro_f1'],f1_score(pred.failure_next_week,pred.predicted_failure,average='macro'),'분류 지표 불일치')
        close(metrics.loc['selected_model','RMSE_minutes'],root_mean_squared_error(pred.maintenance_minutes,pred.predicted_minutes),'RMSE 불일치')
    elif n==3:
        hourly=read(d,'hourly_sensor.csv',['sensor_id','timestamp','obs_count','temp_mean','energy_sum','status','exclusion_reason'])
        unique(hourly,['sensor_id','timestamp'])
        require(len(hourly)==6*96,'센서 × 전체 시간 격자의 행 수 불일치')
        require(hourly.loc[hourly.obs_count.eq(0),['temp_mean','energy_sum']].isna().all().all(),'빈 시간 구간의 값이 0으로 바뀜')
        excluded=read(d,'excluded_intervals.csv')
        same_keys(excluded,hourly.loc[hourly.status.eq('excluded')],['sensor_id','timestamp'])
        require(excluded.exclusion_reason.notna().all(),'예측 제외 이유 누락')
        pred=read(d,'forecast_predictions.csv',['sensor_id','timestamp','forecast_issued_at','target_hour_start','target_hour_end','predicted_temp','next_hour_temp','predicted_threshold_exceeded'])
        same_keys(pred,hourly.loc[hourly.evaluation_period.eq('test') & hourly.status.eq('eligible')],['sensor_id','timestamp'])
        ts=pd.to_datetime(pred.timestamp,utc=True)
        issued=pd.to_datetime(pred.forecast_issued_at,utc=True)
        target_start=pd.to_datetime(pred.target_hour_start,utc=True)
        target_end=pd.to_datetime(pred.target_hour_end,utc=True)
        require(issued.eq(ts+pd.Timedelta(hours=1)).all() and issued.eq(target_start).all(),'예측 시점 불일치')
        require(target_end.eq(target_start+pd.Timedelta(hours=1)).all(),'Target 기간 불일치')
        require(np.isfinite(pred.predicted_temp).all(),'비유한 예측 온도')
        truth=pred.next_hour_temp.ge(32).astype(int)
        close(truth,pred.actual_threshold_exceeded,'기준 초과 실제 Label 불일치')
        metrics=read(d,'forecast_metrics.csv').set_index('model')
        name=next(x for x in metrics.index if x!='persistence')
        close(metrics.loc[name,'RMSE_C'],root_mean_squared_error(pred.next_hour_temp,pred.predicted_temp),'센서 RMSE 불일치')
        cm=read(d,'sensor_classification_metrics.csv').set_index('model')
        close(cm.loc['logistic','macro_f1'],f1_score(truth,pred.predicted_threshold_exceeded,average='macro'),'센서 분류 지표 불일치')
        read(d,'time_cv_scores.csv')
    elif n==4:
        raw=pd.read_json(d/'data/reports.jsonl',lines=True)
        nonempty=raw.text.fillna('').str.strip().ne('')
        test=raw.loc[raw.split.eq('test') & nonempty]
        pred=read(d,'text_predictions.csv',['report_id','label','prediction','max_probability'])
        same_keys(pred,test,'report_id')
        merged=pred.merge(test,on='report_id',suffixes=('_pred','_source'),validate='one_to_one')
        require(merged.label_pred.eq(merged.label_source).all(),'실제 텍스트 Label 대응 불일치')
        require(pred.prediction.isin(raw.label).all(),'알 수 없는 텍스트 Label')
        require(pred.max_probability.between(0,1).all(),'확률 범위 오류')
        errors=read(d,'text_errors.csv')
        same_keys(errors,pred.loc[pred.label.ne(pred.prediction)],'report_id')
        empty=read(d,'empty_reports.csv',['report_id','status'])
        same_keys(empty,raw.loc[~nonempty],'report_id')
        require(empty.status.eq('empty_text').all(),'빈 텍스트 처리 상태 누락')
        metrics=read(d,'text_metrics.csv').set_index('model')
        close(metrics.loc['tfidf_logistic','macro_f1'],f1_score(pred.label,pred.prediction,average='macro'),'텍스트 F1 불일치')
    elif n==5:
        metadata=read(d,'photo_metadata.csv',sub='data')
        pred=read(d,'photo_test_predictions.csv',['image_id','path','label','prediction'])
        test=metadata.loc[metadata.split.eq('test')]
        same_keys(pred,test,'image_id')
        merged=pred.merge(test,on='image_id',suffixes=('_pred','_source'),validate='one_to_one')
        require(merged.label_pred.eq(merged.label_source).all(),'사진 Label 대응 불일치')
        require(pred.prediction.isin(['ants','bees']).all(),'사진 분류 Label 오류')
        metrics=read(d,'photo_metrics.csv').set_index('model')
        close(metrics.loc['frozen_mobilenet_logistic','accuracy'],accuracy_score(pred.label,pred.prediction),'사진 Accuracy 불일치')
        close(metrics.loc['frozen_mobilenet_logistic','macro_f1'],f1_score(pred.label,pred.prediction,average='macro'),'사진 F1 불일치')
        features=np.load(d/'results/extracted_features.npy')
        require(features.shape==(len(metadata),576),'사진 특징 배열 형태 불일치')
        read(d,'validation_scores.csv')
    elif n==6:
        registry=read(d,'photo_registry.csv',sub='data')
        counts=read(d,'photo_counts.csv',['photo_id','status','person_count','vehicle_count'])
        unique(counts,'photo_id');require(set(counts.photo_id)==set(registry.photo_id),'사진 처리 행 누락')
        ok=counts.status.eq('ok')
        require(counts.loc[~ok,['person_count','vehicle_count']].isna().all().all(),'실패 사진의 count가 0으로 바뀜')
        require(counts.loc[ok,['person_count','vehicle_count']].notna().all().all(),'정상 사진 count 누락')
        require(counts.loc[counts.filename.eq('blank.png'),'person_count'].eq(0).all(),'빈 화면의 0건 누락')
        details=read(d,'photo_detections.csv',['photo_id','class_name','confidence','xmin','ymin','xmax','ymax'])
        require(details.confidence.between(.25,1).all(),'탐지 Confidence 범위 오류')
        require(details.xmax.ge(details.xmin).all() and details.ymax.ge(details.ymin).all(),'Box 좌표 오류')
        for row in counts.loc[ok].itertuples():
            subset=details.loc[details.photo_id.eq(row.photo_id)]
            require(row.person_count==subset.class_name.eq('person').sum(),'사진별 사람 합계 불일치')
            require(row.vehicle_count==subset.class_name.isin(['car','bus','truck']).sum(),'사진별 차량 합계 불일치')
        scene=read(d,'scene_summary.csv')
        for row in scene.itertuples():
            group=counts.loc[counts.scene.eq(row.scene)]
            require(row.registered_images==len(group) and row.processed_images==group.status.eq('ok').sum(),'장면별 평균 분모 오류')
            close(row.person_detections,group.person_count.sum(min_count=1),'장면 사람 합계 불일치')
            close(row.mean_person_per_processed_image,group.person_count.mean(),'정상 사진당 평균 오류')
        read(d,'confidence_comparison.csv')
    elif n==7:
        samples=read(d,'video_sample_counts.csv',['video','frame_number','time_seconds','requested_seconds','total_count','status'])
        unique(samples,['video','frame_number'])
        require(samples.status.eq('ok').all(),'샘플 처리 상태 누락')
        truth=read(d,'shape_frame_truth.csv',sub='data')
        controlled=samples.loc[samples.video.eq('moving_shapes.mp4')]
        same_keys(controlled,pd.DataFrame({'frame_number':[round(i*29.97) for i in range(10)]}),'frame_number')
        compared=controlled.merge(truth,on='frame_number',validate='one_to_one')
        close(compared.total_count,compared.object_count,'도형 정답 count 불일치')
        require((controlled.time_seconds-controlled.requested_seconds).abs().le(1/29.97).all(),'요청 시점과 실제 시점 차이 오류')
        require(controlled.loc[controlled.frame_number.eq(0),'total_count'].eq(0).all(),'0건 프레임 누락')
        windows=read(d,'video_windows.csv')
        for video,group in samples.groupby('video'):
            w=windows.loc[windows.video.eq(video)]
            close(w.sample_count.sum(),len(group),'시간 집계의 샘플 수 불일치')
            close((w.mean_count*w.sample_count).sum(),group.total_count.sum(),'시간 집계의 가중 합계 불일치')
        read(d,'video_read_status.csv',['video','declared_frames','decoded_frames','status'])
        read(d,'video_detections.csv')
    elif n==8:
        truth=read(d,'document_truth.csv',sub='data')
        fields=read(d,'document_fields.csv',['filename','status','total_value'])
        same_keys(fields,truth,'filename')
        parsed=fields.status.eq('parsed')
        close(fields.loc[parsed,'total_value'],fields.loc[parsed,'quantity']*fields.loc[parsed,'unit_price']+fields.loc[parsed,'adjustment'],'문서 금액 계산 오류')
        require(fields.loc[~parsed,'total_value'].isna().all(),'검토 문서의 금액이 확정됨')
        compared=truth.merge(fields,on='filename',suffixes=('_true','_pred'),validate='one_to_one')
        scores=read(d,'field_accuracy.csv').set_index('field')
        for field in ['document_id','date','sku','quantity','unit_price','adjustment']:
            actual=compared[field+'_true'];prediction=compared[field+'_pred']
            matches=np.isclose(actual,prediction,equal_nan=False) if field in ['quantity','unit_price','adjustment'] else actual.eq(prediction)
            close(scores.loc[field,'accuracy'],np.mean(matches),'필드 정확도 불일치: '+field)
        read(d,'ocr_raw.csv');read(d,'ocr_words.csv');read(d,'document_comparison.csv')
    return len(list((d/'results').glob('*.csv')))

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--types',type=int,nargs='+',default=list(FOLDERS),choices=list(FOLDERS))
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    args=parser.parse_args();failed=False
    for n in args.types:
        try:
            count=check(n,args.root)
            print(f'{n:02d}: PASS ({count} CSV files)')
        except (ValueError,AssertionError,KeyError,OSError,pd.errors.ParserError) as error:
            failed=True;print(f'{n:02d}: FAIL - {error}')
    raise SystemExit(1 if failed else 0)
