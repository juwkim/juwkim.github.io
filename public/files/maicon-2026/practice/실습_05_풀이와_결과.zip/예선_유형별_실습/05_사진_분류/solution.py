from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path.cwd()
DATA = ROOT / "data"
RESULTS = ROOT / "results"
PLOTS = ROOT / "plots"
RESULTS.mkdir(exist_ok=True)
PLOTS.mkdir(exist_ok=True)

def save_csv(frame, name):
    frame.to_csv(RESULTS / name, index=False, encoding="utf-8-sig")


import hashlib
import torch
from PIL import Image
from torchvision.models import mobilenet_v3_small, MobileNet_V3_Small_Weights
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier
from sklearn.metrics import accuracy_score, f1_score, ConfusionMatrixDisplay

metadata=pd.read_csv(DATA/"photo_metadata.csv")
assert metadata.image_id.is_unique and metadata.sha256.is_unique
for row in metadata.itertuples(index=False):
    assert hashlib.sha256((DATA/row.path).read_bytes()).hexdigest()==row.sha256
print(metadata.groupby(["split","label"]).size().to_string())

torch.set_num_threads(4)
weights=MobileNet_V3_Small_Weights.DEFAULT
network=mobilenet_v3_small(weights=None)
state=torch.load(ROOT.parent/"_models/mobilenet_v3_small-047dcff4.pth",map_location="cpu",weights_only=True)
network.load_state_dict(state)
network.classifier=torch.nn.Identity()
network.requires_grad_(False)
network.eval()
preprocess=weights.transforms()
parts=[]
with torch.inference_mode():
    for start in range(0,len(metadata),8):
        images=[]
        for path in metadata.iloc[start:start+8].path:
            with Image.open(DATA/path) as image:
                images.append(preprocess(image.convert("RGB")))
        parts.append(network(torch.stack(images)).numpy())
features=np.vstack(parts)
np.save(RESULTS/"extracted_features.npy",features)
cached=np.load(DATA/"photo_features.npy")
assert np.allclose(features,cached,atol=1e-5)
print("추출한 특징:",features.shape,"고정된 파라미터:",all(not p.requires_grad for p in network.parameters()))

train=metadata.split.eq("train").to_numpy()
validation=metadata.split.eq("validation").to_numpy()
test=metadata.split.eq("test").to_numpy()
rows=[]
for c in [0.01,0.1,1.0,10.0]:
    candidate=make_pipeline(StandardScaler(),LogisticRegression(C=c,max_iter=2000))
    candidate.fit(features[train],metadata.loc[train,"label"])
    prediction=candidate.predict(features[validation])
    rows.append({"C":c,"validation_macro_f1":f1_score(metadata.loc[validation,"label"],prediction,average="macro")})
scores=pd.DataFrame(rows).sort_values(["validation_macro_f1","C"],ascending=[False,True])
selected_c=float(scores.iloc[0].C)
save_csv(scores,"validation_scores.csv")
print(scores.round(3).to_string(index=False))
print("선택한 C:",selected_c)

train_validation=train|validation
model=make_pipeline(StandardScaler(),LogisticRegression(C=selected_c,max_iter=2000))
model.fit(features[train_validation],metadata.loc[train_validation,"label"])
predicted=model.predict(features[test])
dummy=DummyClassifier(strategy="most_frequent").fit(features[train_validation],metadata.loc[train_validation,"label"])
metrics=pd.DataFrame([{"model":name,"accuracy":accuracy_score(metadata.loc[test,"label"],pred),"macro_f1":f1_score(metadata.loc[test,"label"],pred,average="macro")} for name,pred in [("frozen_mobilenet_logistic",predicted),("dummy",dummy.predict(features[test]))]])
save_csv(metrics,"photo_metrics.csv")
prediction=metadata.loc[test,["image_id","path","label"]].copy()
prediction["prediction"]=predicted
save_csv(prediction,"photo_test_predictions.csv")
print(metrics.round(3).to_string(index=False))
fig,axes=plt.subplots(1,2,figsize=(10,4))
ConfusionMatrixDisplay.from_predictions(metadata.loc[test,"label"],predicted,labels=["ants","bees"],ax=axes[0],colorbar=False)
axes[0].set_title("Tutorial subset: held-out photos")
error=prediction.loc[prediction.label.ne(prediction.prediction)]
example=error.iloc[0] if len(error) else prediction.iloc[0]
with Image.open(DATA/example.path) as image: axes[1].imshow(image.convert("RGB"))
axes[1].set_title(f"Actual: {example.label}, predicted: {example.prediction}");axes[1].axis("off")
fig.tight_layout();fig.savefig(PLOTS/"photo_evaluation.png",dpi=150,bbox_inches="tight");plt.close(fig)
print("오류 사진:",len(error))
