# Test에서 다시 fit하면 특징의 좌표계가 바뀝니다
# 자료: 실습의 고정 CNN 특징
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

metadata = pd.read_csv("data/photo_metadata.csv")
features = np.load("results/extracted_features.npy")
train = features[metadata.split.eq("train").to_numpy()]
test = features[metadata.split.eq("test").to_numpy()]
columns = np.argsort(train.var(axis=0))[-3:]
train_scaler = StandardScaler().fit(train[:, columns])
proper_test = train_scaler.transform(test[:, columns])
refitted_test = StandardScaler().fit_transform(test[:, columns])
comparison = pd.DataFrame({"feature": columns, "mean_train_reference": proper_test.mean(axis=0), "mean_refitted_on_test": refitted_test.mean(axis=0)})
print(comparison.round(4).to_string(index=False))
print("변환값의 평균 절대 차이:", round(float(np.abs(proper_test - refitted_test).mean()), 4))


# Validation 선택과 Test 선택을 나눠 생각합니다
# 자료: 선택 원리를 보여 주는 가상 점수표
import pandas as pd

scores = pd.DataFrame({"C": [0.1, 1.0, 10.0], "validation_f1": [0.80, 0.90, 0.85], "test_f1": [0.95, 0.84, 0.88]})
selected_validation = scores.sort_values(["validation_f1", "C"], ascending=[False, True]).iloc[0]
selected_test = scores.sort_values(["test_f1", "C"], ascending=[False, True]).iloc[0]
print(scores.to_string(index=False))
print("Validation에서 선택한 C:", selected_validation.C)
print("Test를 보고 선택한 C:", selected_test.C)
