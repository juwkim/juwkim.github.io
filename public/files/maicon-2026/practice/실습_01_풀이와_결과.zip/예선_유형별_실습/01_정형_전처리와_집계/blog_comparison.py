# 기준표의 중복 키가 거래 행을 늘리는 경우
# 자료: 실습 입력 데이터
import json
import pandas as pd

events = pd.read_csv("data/logistics_raw.csv")
events["updated_at"] = pd.to_datetime(events.updated_at, utc=True)
events = events.sort_values("updated_at").drop_duplicates("event_id", keep="last")
registry = pd.json_normalize(json.loads(open("data/unit_registry.json", encoding="utf-8").read()))
registry["updated_at"] = pd.to_datetime(registry.updated_at, utc=True)
latest_registry = registry.sort_values("updated_at").drop_duplicates("unit_id", keep="last")
wrong = events.merge(registry, on="unit_id", how="left")
correct = events.merge(latest_registry, on="unit_id", how="left", validate="many_to_one")
print("거래 목록:", len(events))
print("중복 기준표 연결:", len(wrong))
print("최신 기준표 연결:", len(correct))
assert len(correct) == len(events)


# 관측하지 못한 팀과 수량 0인 팀을 구분합니다
# 자료: 실습에서 저장한 결과
import pandas as pd

totals = pd.read_csv("results/unit_totals.csv")
comparison = totals[["unit_id", "valid_records", "quantity_piece"]].copy()
comparison["zero_filled_quantity"] = comparison.quantity_piece.fillna(0)
comparison["meaning"] = comparison.quantity_piece.isna().map({True: "unobserved", False: "observed"})
print(comparison.to_string(index=False))
print("관측하지 못한 팀:", int(comparison.quantity_piece.isna().sum()))
