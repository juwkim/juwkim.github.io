from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path.cwd()
DATA = ROOT / "data"
RESULTS = ROOT / "results"
PLOTS = ROOT / "plots"
RESULTS.mkdir(exist_ok=True)
PLOTS.mkdir(exist_ok=True)

def save_csv(frame, name):
    frame.to_csv(RESULTS / name, index=False, encoding="utf-8-sig")


raw = pd.read_csv(DATA / "logistics_raw.csv", dtype={"event_id":"string", "unit_id":"string"})
registry = pd.json_normalize(json.loads((DATA / "unit_registry.json").read_text()))
catalog = pd.read_csv(DATA / "item_catalog.csv")
print("원본 행:", len(raw), "중복 event_id:", int(raw.event_id.duplicated().sum()))
print(registry.columns.tolist())

raw["updated_at"] = pd.to_datetime(raw["updated_at"], utc=True, errors="raise")
events = raw.sort_values("updated_at").drop_duplicates("event_id", keep="last").copy()
registry["updated_at"] = pd.to_datetime(registry["updated_at"], utc=True)
units = registry.sort_values("updated_at").drop_duplicates("unit_id", keep="last")
units = units.rename(columns={"profile.name":"unit_name", "profile.region":"region"})
events = events.merge(units[["unit_id","unit_name","region"]], on="unit_id", how="left", validate="many_to_one", indicator="unit_match")
events = events.merge(catalog, on="item_id", how="left", validate="many_to_one")
assert len(events) == raw.event_id.nunique()
print("최신 event:", len(events), "등록 팀:", len(units))

events["timestamp"] = pd.to_datetime(events["timestamp"], utc=True, errors="coerce")
events["quantity_numeric"] = pd.to_numeric(events["quantity"], errors="coerce")
factor = events["quantity_unit"].map({"piece":1.0, "box":np.nan})
factor = factor.where(events["quantity_unit"].ne("box"), events["pieces_per_box"])
events["quantity_piece"] = events["quantity_numeric"] * factor
checks = {
    "missing_unit": events.unit_id.isna(),
    "unregistered_unit": events.unit_id.notna() & events.unit_match.ne("both"),
    "invalid_time": events.timestamp.isna(),
    "unknown_item": events.pieces_per_box.isna(),
    "invalid_quantity": events.quantity_numeric.isna() | events.quantity_numeric.lt(0),
    "unknown_unit": ~events.quantity_unit.isin(["piece","box"]),
    "fractional_piece": events.quantity_piece.notna() & ~np.isclose(events.quantity_piece.fillna(0) % 1, 0),
}
flags = pd.DataFrame(checks)
events["reject_reason"] = flags.apply(lambda row: "|".join(row.index[row]), axis=1)
accepted = events.loc[events.reject_reason.eq("")].copy()
rejected = events.loc[events.reject_reason.ne("")].copy()
accepted["quantity_piece"] = accepted["quantity_piece"].astype("Int64")
assert len(accepted) + len(rejected) == len(events)
save_csv(accepted, "clean_records.csv")
save_csv(rejected, "rejected_records.csv")
print("유효 기록:", len(accepted), "Reject:", len(rejected))
print(flags.sum().to_string())

accepted["day"] = accepted["timestamp"].dt.floor("D")
daily = accepted.groupby(["day","unit_id","unit_name"], as_index=False).agg(quantity_piece=("quantity_piece","sum"), valid_records=("event_id","size"))
totals = units[["unit_id","unit_name"]].merge(accepted.groupby("unit_id", as_index=False).agg(quantity_piece=("quantity_piece",lambda s:s.sum(min_count=1)), valid_records=("event_id","size")), how="left", on="unit_id", validate="one_to_one")
totals["valid_records"] = totals.valid_records.fillna(0).astype(int)
assert daily.quantity_piece.sum() == accepted.quantity_piece.sum()
save_csv(daily,"daily_unit_summary.csv")
save_csv(totals,"unit_totals.csv")
quality = pd.DataFrame({"check":["raw_rows","unique_events","accepted","rejected","duplicate_versions"],"value":[len(raw),len(events),len(accepted),len(rejected),len(raw)-len(events)]})
save_csv(quality,"quality_report.csv")
print(totals.to_string(index=False))
fig, ax = plt.subplots(figsize=(7,4))
observed = totals.loc[totals.quantity_piece.notna()]
ax.bar(observed.unit_id, observed.quantity_piece, color="#3a9a90")
ax.set(xlabel="Unit",ylabel="Valid quantity (pieces)",title="Observed supply quantity")
fig.tight_layout(); fig.savefig(PLOTS/"unit_totals.png",dpi=150); plt.close(fig)
