# 문장이 달라도 같은 양식이 양쪽에 들어갈 수 있습니다
# 자료: 실습 입력 데이터
import pandas as pd
from sklearn.model_selection import train_test_split

reports = pd.read_json("data/reports.jsonl", lines=True)
usable = reports.loc[reports.text.fillna("").str.strip().ne("")].copy()
left, right = train_test_split(usable, test_size=0.3, random_state=42, stratify=usable.label)
random_overlap = set(left.template_group) & set(right.template_group)
fixed_overlap = set(usable.loc[usable.split.eq("train"), "template_group"]) & set(usable.loc[usable.split.eq("test"), "template_group"])
print("무작위 분할의 양식 교집합:", len(random_overlap))
print("제공한 분할의 양식 교집합:", len(fixed_overlap))
assert not fixed_overlap


# 확률 점수와 실제 정답 여부를 함께 확인합니다
# 자료: 실습에서 저장한 예측 결과
import pandas as pd

prediction = pd.read_csv("results/text_predictions.csv")
prediction["correct"] = prediction.label.eq(prediction.prediction)
prediction["score_band"] = pd.cut(prediction.max_probability, bins=[0, 0.4, 0.6, 0.8, 1.0], include_lowest=True)
summary = prediction.groupby("score_band", observed=True).agg(
    reports=("report_id", "size"), observed_accuracy=("correct", "mean"),
    mean_max_probability=("max_probability", "mean"))
print(summary.round(3).to_string())
print("클래스별 정답률:")
print(prediction.groupby("label").correct.agg(["size", "mean"]).round(3).to_string())
