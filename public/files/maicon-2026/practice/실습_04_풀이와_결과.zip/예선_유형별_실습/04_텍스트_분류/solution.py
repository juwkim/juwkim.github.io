from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path.cwd()
DATA = ROOT / "data"
RESULTS = ROOT / "results"
PLOTS = ROOT / "plots"
RESULTS.mkdir(exist_ok=True)
PLOTS.mkdir(exist_ok=True)

def save_csv(frame, name):
    frame.to_csv(RESULTS / name, index=False, encoding="utf-8-sig")


from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedGroupKFold, GridSearchCV
from sklearn.dummy import DummyClassifier
from sklearn.metrics import f1_score, classification_report, ConfusionMatrixDisplay
import re

records=pd.read_json(DATA/"reports.jsonl",lines=True)
records["clean_text"]=records.text.fillna("").map(lambda text: re.sub(r"\s+"," ",text).strip())
empty=records.loc[records.clean_text.eq("")].copy()
empty["status"]="empty_text"
save_csv(empty,"empty_reports.csv")
usable=records.loc[records.clean_text.ne("")].copy()
train=usable.loc[usable.split.eq("train")].copy()
test=usable.loc[usable.split.eq("test")].copy()
assert set(train.template_group).isdisjoint(test.template_group)
assert set(train.clean_text).isdisjoint(test.clean_text)
print("원문:",len(records),"빈 입력:",len(empty),"Train/Test:",len(train),len(test))
print("Train의 완전 중복:",int(train.clean_text.duplicated().sum()))

pipeline=Pipeline([
    ("tfidf",TfidfVectorizer(analyzer="char",ngram_range=(2,5),min_df=2,max_features=12000)),
    ("model",LogisticRegression(max_iter=2000)),
])
folds=list(StratifiedGroupKFold(n_splits=3,shuffle=True,random_state=42).split(train.clean_text,train.label,groups=train.template_group))
search=GridSearchCV(pipeline,{"model__C":[0.2,1.0,3.0]},cv=folds,scoring="f1_macro")
search.fit(train.clean_text,train.label)
model=search.best_estimator_
print("선택:",search.best_params_,"CV macro F1:",round(search.best_score_,3))
print("학습한 Vocabulary 수:",len(model.named_steps["tfidf"].vocabulary_))

predicted=model.predict(test.clean_text)
dummy=DummyClassifier(strategy="most_frequent").fit(np.zeros((len(train),1)),train.label)
dummy_pred=dummy.predict(np.zeros((len(test),1)))
metrics=pd.DataFrame({"model":["tfidf_logistic","dummy"],"macro_f1":[f1_score(test.label,predicted,average="macro"),f1_score(test.label,dummy_pred,average="macro")]})
save_csv(metrics,"text_metrics.csv")
print(metrics.round(3).to_string(index=False))
print(classification_report(test.label,predicted,zero_division=0))
probability=model.predict_proba(test.clean_text)
prediction=test[["report_id","template_group","text","label"]].copy()
prediction["prediction"]=predicted
prediction["max_probability"]=probability.max(axis=1)
prediction["status"]="ok"
save_csv(prediction,"text_predictions.csv")
errors=prediction.loc[prediction.label.ne(prediction.prediction)]
save_csv(errors,"text_errors.csv")
print("잘못 분류한 기록:",len(errors))
fig,ax=plt.subplots(figsize=(6,5))
ConfusionMatrixDisplay.from_predictions(test.label,predicted,labels=model.classes_,ax=ax,colorbar=False)
ax.set_title("Text classification: unseen templates")
fig.tight_layout();fig.savefig(PLOTS/"text_confusion.png",dpi=150,bbox_inches="tight");plt.close(fig)
