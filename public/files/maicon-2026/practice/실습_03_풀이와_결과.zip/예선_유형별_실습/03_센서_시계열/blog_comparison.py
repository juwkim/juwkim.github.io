# 중앙 이동평균에 미래 값이 들어갑니다
# 자료: 시간 관계를 확인하는 작은 예제
import pandas as pd

temperature = pd.Series([20.0, 21.0, 22.0, 100.0, 24.0], name="temperature")
comparison = pd.DataFrame({
    "current": temperature,
    "centered_rolling3": temperature.rolling(3, center=True).mean(),
    "completed_rolling3": temperature.rolling(3).mean(),
    "previous_rolling3": temperature.shift(1).rolling(3).mean(),
})
print(comparison.round(3).to_string())
assert comparison.loc[2, "centered_rolling3"] > 40
assert comparison.loc[2, "completed_rolling3"] == 21


# 현재 기준 초과와 다음 시간 기준 초과는 다른 Target입니다
# 자료: 분류 Target을 확인하는 작은 예제
import pandas as pd

example = pd.DataFrame({"current_temp": [30, 34, 31, 35], "next_hour_temp": [34, 31, 35, 28]})
example["current_exceeded"] = example.current_temp.ge(32).astype(int)
example["next_hour_exceeded"] = example.next_hour_temp.ge(32).astype(int)
print(example.to_string(index=False))
print("서로 다른 Target 행:", int(example.current_exceeded.ne(example.next_hour_exceeded).sum()))
