from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path.cwd()
DATA = ROOT / "data"
RESULTS = ROOT / "results"
PLOTS = ROOT / "plots"
RESULTS.mkdir(exist_ok=True)
PLOTS.mkdir(exist_ok=True)

def save_csv(frame, name):
    frame.to_csv(RESULTS / name, index=False, encoding="utf-8-sig")


from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import TimeSeriesSplit, GridSearchCV
from sklearn.metrics import root_mean_squared_error, mean_absolute_error

config=json.loads((DATA/"sensor_config.json").read_text())
logs=pd.read_csv(DATA/"sensor_logs.csv")
logs["timestamp"]=pd.to_datetime(logs["timestamp"],utc=True,errors="raise")
low,high=config["valid_temperature_range_c"]
logs["temperature_valid"]=logs.temperature_c.where(logs.temperature_c.between(low,high))
logs=logs.sort_values(["sensor_id","timestamp"])
assert not logs.duplicated(["sensor_id","timestamp"]).any()
print("원본 기록:",len(logs),"허용 범위 밖 온도:",int(logs.temperature_valid.isna().sum()))

grid=pd.date_range(config["start"],periods=config["periods"],freq="1h",name="timestamp")
parts=[]
for sensor_id,group in logs.groupby("sensor_id"):
    hourly=group.set_index("timestamp").resample("1h",closed="left",label="left").agg(
        temp_mean=("temperature_valid","mean"),
        obs_count=("log_id","size"),valid_temp_count=("temperature_valid","count"),
        energy_sum=("energy_kwh",lambda s:s.sum(min_count=1)),
    ).reindex(grid)
    hourly[["obs_count","valid_temp_count"]]=hourly[["obs_count","valid_temp_count"]].fillna(0).astype(int)
    hourly["coverage"]=hourly["obs_count"]/config["expected_records_per_hour"]
    hourly["sensor_id"]=sensor_id
    parts.append(hourly.reset_index())
hourly=pd.concat(parts,ignore_index=True).sort_values(["sensor_id","timestamp"])
assert len(hourly)==6*config["periods"]
save_csv(hourly,"hourly_sensor.csv")
print("시간별 표:",len(hourly),"완전히 빈 시간:",int(hourly.obs_count.eq(0).sum()))
print(hourly.loc[hourly.obs_count.eq(0),["sensor_id","timestamp","temp_mean","energy_sum"]].to_string(index=False))

groups=hourly.groupby("sensor_id",sort=False)
hourly["temp_lag1"]=groups.temp_mean.shift(1)
hourly["temp_lag3"]=groups.temp_mean.shift(3)
hourly["past_rolling3"]=groups.temp_mean.transform(lambda s:s.shift(1).rolling(3,min_periods=2).mean())
hourly["next_hour_temp"]=groups.temp_mean.shift(-1)
hourly["hour_sin"]=np.sin(2*np.pi*hourly.timestamp.dt.hour/24)
hourly["hour_cos"]=np.cos(2*np.pi*hourly.timestamp.dt.hour/24)
features=["temp_mean","temp_lag1","temp_lag3","past_rolling3","energy_sum","obs_count","hour_sin","hour_cos"]
# 현재 온도가 없는 구간은 예측에서 제외하고 원본 시간 표에는 남깁니다.
hourly["forecast_issued_at"]=hourly.timestamp+pd.Timedelta(hours=1)
hourly["target_hour_start"]=hourly.timestamp+pd.Timedelta(hours=1)
hourly["target_hour_end"]=hourly.timestamp+pd.Timedelta(hours=2)
hourly["forecast_eligible"]=hourly.next_hour_temp.notna() & hourly.temp_mean.notna()
hourly["exclusion_reason"]=np.select(
    [hourly.temp_mean.isna() & hourly.next_hour_temp.isna(),
     hourly.temp_mean.isna(), hourly.next_hour_temp.isna()],
    ["current_and_target_missing","current_missing","target_missing"],default="")
eligible=hourly.loc[hourly.forecast_eligible].copy()
cutoff=pd.Timestamp(config["test_starts"])
train=eligible.loc[eligible.timestamp.lt(cutoff-pd.Timedelta(hours=1))].copy()
test=eligible.loc[eligible.timestamp.ge(cutoff)].copy()
assert train.timestamp.max()+pd.Timedelta(hours=1)<test.timestamp.min()
print("Train:",len(train),"Test:",len(test),"예측 대상 제외:",len(hourly)-len(eligible))
hourly["evaluation_period"]=np.select(
    [hourly.timestamp.lt(cutoff-pd.Timedelta(hours=1)),hourly.timestamp.ge(cutoff)],
    ["train","test"],default="boundary_gap")
hourly["status"]=np.where(hourly.forecast_eligible,"eligible","excluded")
save_csv(hourly,"hourly_sensor.csv")
save_csv(hourly.loc[~hourly.forecast_eligible],"excluded_intervals.csv")
print("시간별 처리 상태:",hourly.status.value_counts().to_dict())

times=np.array(sorted(train.timestamp.unique()))
folds=[]
for train_time_idx,valid_time_idx in TimeSeriesSplit(n_splits=3,gap=1).split(times):
    train_rows=np.flatnonzero(train.timestamp.isin(times[train_time_idx]))
    valid_rows=np.flatnonzero(train.timestamp.isin(times[valid_time_idx]))
    assert train.iloc[train_rows].timestamp.max()+pd.Timedelta(hours=1)<train.iloc[valid_rows].timestamp.min()
    folds.append((train_rows,valid_rows))
def prepare(model):
    return Pipeline([("impute",SimpleImputer(strategy="median")),("scale",StandardScaler()),("model",model)])
ridge=GridSearchCV(prepare(Ridge()),{"model__alpha":[0.1,1,10]},cv=folds,scoring="neg_root_mean_squared_error")
forest=GridSearchCV(prepare(RandomForestRegressor(n_estimators=60,random_state=42,n_jobs=1)),{"model__max_depth":[4,8]},cv=folds,scoring="neg_root_mean_squared_error")
searches={"ridge":ridge,"forest":forest}
for search in searches.values(): search.fit(train[features],train.next_hour_temp)
cv_report=pd.DataFrame([{"model":name,"CV_RMSE":-search.best_score_,"settings":str(search.best_params_)} for name,search in searches.items()])
save_csv(cv_report,"time_cv_scores.csv")
selected_name=max(searches,key=lambda name:searches[name].best_score_)
selected=searches[selected_name]
print(cv_report.round(3).to_string(index=False))
print("Train CV로 선택:",selected_name)

predicted=selected.predict(test[features])
baseline=test.temp_mean.to_numpy()
metrics=pd.DataFrame([{"model":name,"RMSE_C":root_mean_squared_error(test.next_hour_temp,pred),"MAE_C":mean_absolute_error(test.next_hour_temp,pred)} for name,pred in [(selected_name,predicted),("persistence",baseline)]])
save_csv(metrics,"forecast_metrics.csv")
prediction=test[["sensor_id","timestamp","forecast_issued_at","target_hour_start","target_hour_end","next_hour_temp","obs_count","coverage"]].copy()
prediction["prediction_for_hour"]=prediction.timestamp+pd.Timedelta(hours=1)
prediction["predicted_temp"]=predicted
prediction["baseline_temp"]=baseline
save_csv(prediction,"forecast_predictions.csv")
print(metrics.round(3).to_string(index=False))
fig,axes=plt.subplots(2,1,figsize=(10,6))
sample=hourly.loc[hourly.sensor_id.eq("S02")]
axes[0].plot(sample.timestamp,sample.temp_mean,color="#3a9a90")
axes[0].set(title="S02: hourly mean, gaps preserved",ylabel="Temperature (C)")
forecast=prediction.loc[prediction.sensor_id.eq("S02")]
axes[1].plot(forecast.prediction_for_hour,forecast.next_hour_temp,label="Actual",marker=".")
axes[1].plot(forecast.prediction_for_hour,forecast.predicted_temp,label="Prediction",marker="x")
axes[1].set(ylabel="Next-hour mean (C)");axes[1].legend()
fig.autofmt_xdate();fig.tight_layout();fig.savefig(PLOTS/"sensor_forecast.png",dpi=150,bbox_inches="tight");plt.close(fig)

from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier
from sklearn.metrics import f1_score, balanced_accuracy_score, ConfusionMatrixDisplay

threshold_c=32.0  # 이 실습에서 정한 가상의 운영 기준입니다.
y_train=(train.next_hour_temp>=threshold_c).astype(int)
y_test=(test.next_hour_temp>=threshold_c).astype(int)
class_search=GridSearchCV(
    prepare(LogisticRegression(max_iter=2000,class_weight="balanced")),
    {"model__C":[0.1,1.0,10.0]},cv=folds,scoring="f1_macro")
class_search.fit(train[features],y_train)
class_pred=class_search.predict(test[features])
dummy=DummyClassifier(strategy="most_frequent").fit(train[features],y_train)
class_metrics=pd.DataFrame([
    {"model":name,"macro_f1":f1_score(y_test,pred,average="macro",zero_division=0),
     "balanced_accuracy":balanced_accuracy_score(y_test,pred)}
    for name,pred in [("logistic",class_pred),("dummy",dummy.predict(test[features]))]])
save_csv(class_metrics,"sensor_classification_metrics.csv")
prediction["actual_threshold_exceeded"]=y_test.to_numpy()
prediction["predicted_threshold_exceeded"]=class_pred
save_csv(prediction,"forecast_predictions.csv")
print("Train에서 선택한 C:",class_search.best_params_)
print("Test 클래스별 구간 수:",y_test.value_counts().sort_index().to_dict())
print(class_metrics.round(3).to_string(index=False))
fig,ax=plt.subplots(figsize=(5,4))
ConfusionMatrixDisplay.from_predictions(y_test,class_pred,labels=[0,1],
    display_labels=["below 32 C","32 C or above"],ax=ax,colorbar=False)
ax.set_title("Next-hour threshold classification")
fig.tight_layout();fig.savefig(PLOTS/"sensor_classification.png",dpi=150,bbox_inches="tight");plt.close(fig)
