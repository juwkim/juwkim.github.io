# 정수 프레임 간격을 반복하면 시간이 밀릴 수 있습니다
# 자료: 29.97 FPS의 가상 600초 시간 계산
import pandas as pd

fps = 29.97
rows = []
for requested_seconds in [1, 60, 300, 600]:
    accumulated_frame = requested_seconds * round(fps)
    direct_frame = round(requested_seconds * fps)
    rows.append({"requested_seconds": requested_seconds, "accumulated_actual_seconds": accumulated_frame / fps, "direct_actual_seconds": direct_frame / fps, "accumulated_error_seconds": accumulated_frame / fps - requested_seconds})
print(pd.DataFrame(rows).round(6).to_string(index=False))


# 객체가 없던 프레임도 평균에 포함합니다
# 자료: 실습에서 저장한 도형 영상 샘플
import pandas as pd

samples = pd.read_csv("results/video_sample_counts.csv")
shapes = samples.loc[samples.video.eq("moving_shapes.mp4") & samples.status.eq("ok")]
positive = shapes.loc[shapes.total_count.gt(0)]
print("전체 정상 샘플:", len(shapes))
print("객체 0개 샘플:", int(shapes.total_count.eq(0).sum()))
print("모든 정상 샘플의 평균:", round(shapes.total_count.mean(), 3))
print("양수 샘플만 남긴 평균:", round(positive.total_count.mean(), 3))
print("샘플별 개수:", shapes.total_count.tolist())
