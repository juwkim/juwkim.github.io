from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path.cwd()
DATA = ROOT / "data"
RESULTS = ROOT / "results"
PLOTS = ROOT / "plots"
RESULTS.mkdir(exist_ok=True)
PLOTS.mkdir(exist_ok=True)

def save_csv(frame, name):
    frame.to_csv(RESULTS / name, index=False, encoding="utf-8-sig")


import cv2
import torch
from ultralytics import YOLO

torch.set_num_threads(2)
model=YOLO(str(ROOT.parent/"_models/yolov5su.pt"))
truth=pd.read_csv(DATA/"shape_frame_truth.csv")
for filename in ["drone_mission.mp4","moving_shapes.mp4"]:
    cap=cv2.VideoCapture(str(DATA/"videos"/filename))
    assert cap.isOpened()
    print(filename,"FPS:",cap.get(cv2.CAP_PROP_FPS),"프레임:",int(cap.get(cv2.CAP_PROP_FRAME_COUNT)))
    cap.release()

sample_rows=[]; detection_rows=[]; status_rows=[]
for filename in ["drone_mission.mp4","moving_shapes.mp4"]:
    cap=cv2.VideoCapture(str(DATA/"videos"/filename))
    if not cap.isOpened(): raise ValueError(f"영상 열기 실패: {filename}")
    fps=cap.get(cv2.CAP_PROP_FPS)
    declared=int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if not np.isfinite(fps) or fps<=0: raise ValueError("유효한 FPS가 필요합니다.")
    frame_number=0; sample_number=0; next_frame=0
    try:
        while True:
            ok,frame=cap.read()
            if not ok: break
            if frame_number==next_frame:
                if filename=="moving_shapes.mp4":
                    hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
                    mask=cv2.inRange(hsv,np.array([0,80,70]),np.array([179,255,255]))
                    labels,_,stats,_=cv2.connectedComponentsWithStats(mask)
                    total=int((stats[1:,cv2.CC_STAT_AREA]>=200).sum())
                    person=0
                else:
                    result=model.predict(frame,imgsz=640,conf=.25,iou=.45,device="cpu",verbose=False)[0]
                    names=[result.names[int(c)] for c in result.boxes.cls.cpu().tolist()]
                    total=len(names);person=names.count("person")
                    for i,(box,confidence,class_id) in enumerate(zip(result.boxes.xyxy.cpu().numpy(),result.boxes.conf.cpu().numpy(),result.boxes.cls.cpu().numpy())):
                        detection_rows.append({"video":filename,"frame_number":frame_number,"time_seconds":frame_number/fps,"detection_index":i,"class_name":result.names[int(class_id)],"confidence":float(confidence),"xmin":float(box[0]),"ymin":float(box[1]),"xmax":float(box[2]),"ymax":float(box[3])})
                sample_rows.append({"video":filename,"sample_number":sample_number,"requested_seconds":float(sample_number),"frame_number":frame_number,"time_seconds":frame_number/fps,"backend_position_ms":cap.get(cv2.CAP_PROP_POS_MSEC),"total_count":total,"person_count":person,"status":"ok"})
                sample_number+=1;next_frame=round(sample_number*fps)
            frame_number+=1
    finally:
        cap.release()
    status_rows.append({"video":filename,"declared_frames":declared,"decoded_frames":frame_number,"status":"ok" if frame_number==declared else "early_end"})
samples=pd.DataFrame(sample_rows)
detections=pd.DataFrame(detection_rows,columns=["video","frame_number","time_seconds","detection_index","class_name","confidence","xmin","ymin","xmax","ymax"])
save_csv(samples,"video_sample_counts.csv");save_csv(detections,"video_detections.csv")
save_csv(pd.DataFrame(status_rows),"video_read_status.csv")
print(samples[["video","requested_seconds","frame_number","time_seconds","total_count"]].round(4).to_string(index=False))

controlled=samples.loc[samples.video.eq("moving_shapes.mp4")].merge(truth[["frame_number","object_count"]],on="frame_number",validate="one_to_one")
assert controlled.total_count.eq(controlled.object_count).all()
assert np.abs(controlled.time_seconds-controlled.requested_seconds).max()<=1/29.97
windows=[]
for video,group in samples.groupby("video"):
    indexed=group.set_index(pd.to_timedelta(group.time_seconds,unit="s"))
    summary=indexed.resample("2s",closed="left",label="left").agg(mean_count=("total_count","mean"),max_count=("total_count","max"),sample_count=("total_count","count"))
    summary.index.name="elapsed_window";summary=summary.reset_index();summary["video"]=video;windows.append(summary)
summary=pd.concat(windows,ignore_index=True);save_csv(summary,"video_windows.csv")
print("도형 샘플 정답 일치:",len(controlled),"/",len(controlled))
print(summary.round(3).to_string(index=False))
fig,axes=plt.subplots(2,1,figsize=(9,6))
for ax,(video,group) in zip(axes,samples.groupby("video",sort=True)):
    ax.plot(group.time_seconds,group.total_count,marker="o",color="#3a9a90")
    ax.set(title=video,xlabel="Elapsed seconds",ylabel="Detections / shapes")
    ax.grid(alpha=.2)
fig.tight_layout();fig.savefig(PLOTS/"video_counts.png",dpi=150,bbox_inches="tight");plt.close(fig)
